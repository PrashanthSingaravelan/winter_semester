<<<<<<< HEAD
#include<graphics.h>
int main()
{
        int gd =DETECT;
        int gm;
        initgraph(&gd,&gm,"C:\\TC\\BGI");
        // void arc(int x, int y, int start_angle,int end_angle, int radius);
        arc(100,100,0,130,50);
        getch();
        closegraph();
}
=======
#include<graphics.h>
int main()
{
        int gd =DETECT;
        int gm;
        initgraph(&gd,&gm,"C:\\TC\\BGI");
        // void arc(int x, int y, int start_angle,int end_angle, int radius);
        arc(100,100,0,130,50);
        getch();
        closegraph();
}
>>>>>>> e9b11b521720e3d1b4f999e344dd740834cb7c44
