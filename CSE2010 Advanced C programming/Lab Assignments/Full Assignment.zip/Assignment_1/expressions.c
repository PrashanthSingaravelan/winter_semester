#include<stdio.h>
#include<conio.h>

int main() {
	int a = 0;
	int b = 2;
	int c = -2;

	int result = --a*(10-b)/2-c++*b+(a+b+c);
	printf("%d",result);
	return 0;
}

